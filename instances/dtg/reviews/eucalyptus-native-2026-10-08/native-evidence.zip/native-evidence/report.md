# Supplemental Eucalyptus native evidence

**Overall assurance remains INDETERMINATE.**

The sealed initial campaign is retained. This packet records additional native attempts and actual resolved build inputs.

| Attempt | State | Passing native tests | Build input state |
|---|---|---:|---|
| rust-openvtc | EXECUTED_NONZERO | 957 | release-locked |
| rust-verifiable-trust-infrastructure | ATTEMPTED_UNAVAILABLE | 0 | release-locked |
| rust-affinidi-tdk-rs | EXECUTED_PASS | 3905 | release-locked |
| rust-affinidi-webvh-service | EXECUTED_PASS | 1220 | release-locked |
| rust-affinidi-trust-registry-rs | EXECUTED_NONZERO | 290 | release-locked |
| rust-dtgwg-trust-tasks-tf | EXECUTED_PASS | 1459 | release-locked |
| rust-verifiable-git-infrastructure | EXECUTED_PASS | 820 | release-locked |
| rust-didwebvh-rs | EXECUTED_PASS | 523 | release-locked |
| rust-dtg-credentials | EXECUTED_PASS | 213 | fresh-resolution-not-release-locked |
| rust-predicate-credential-system | EXECUTED_PASS | 446 | release-locked |
| rust-vta-agent-memory | EXECUTED_PASS | 119 | release-locked |
| rust-vti-push-gateway | EXECUTED_PASS | 141 | release-locked |
| go-tsp | EXECUTED_PASS | 782 | release-locked |
| dart-tsp | EXECUTED_NONZERO | 39 | fresh-resolution-not-release-locked |
| dart-tsp-package | EXECUTED_PASS | 83 | fresh-resolution-not-release-locked |
| ios-approval | EXECUTED_NONZERO | 0 | fresh-resolution-not-release-locked |
| lab-room-handoff | ATTEMPTED_UNAVAILABLE | 0 | fresh-resolution-not-release-locked |
| lab-privacy-handoff | ATTEMPTED_UNAVAILABLE | 0 | fresh-resolution-not-release-locked |
| vtc-sender | EXECUTED_PASS | 5 | release-locked |
| vtc-self-edit | EXECUTED_PASS | 11 | release-locked |
| vtc-consent | EXECUTED_PASS | 31 | release-locked |
| vta-freshness | EXECUTED_PASS | 3 | release-locked |
| vta-refresh | EXECUTED_PASS | 5 | release-locked |
| rooms-native | EXECUTED_PASS | 198 | release-locked |
| vetting-native | EXECUTED_PASS | 7 | release-locked |
| e2e-native | EXECUTED_PASS | 271 | release-locked |

Actual deployment, observer captures, real participant independence, Apple device and accessibility/redress evidence remain required. Native fixture passes are bounded.

Counts are test events, not distinct assurance claims; suites may overlap. Full commands, versions, revisions and logs are in the sealed machine records.
